import csv
import sqlite3


# used chatgpt to create this mapping th eocnverastion is here https://chatgpt.com/share/673f0712-ca8c-8008-be7d-2aa18ff974b9
continent_mapping = {
    'AF': 'Asia', 'AL': 'Europe', 'DZ': 'Africa', 'AS': 'Oceania', 'AD': 'Europe',
    'AO': 'Africa', 'AI': 'North America', 'AQ': 'Antarctica', 'AG': 'North America', 'AR': 'South America',
    'AM': 'Asia', 'AW': 'North America', 'AU': 'Oceania', 'AT': 'Europe', 'AZ': 'Asia',
    'BS': 'North America', 'BH': 'Asia', 'BD': 'Asia', 'BB': 'North America', 'BY': 'Europe',
    'BE': 'Europe', 'BZ': 'North America', 'BJ': 'Africa', 'BM': 'North America', 'BT': 'Asia',
    'BO': 'South America', 'BA': 'Europe', 'BW': 'Africa', 'BR': 'South America',
    'BN': 'Asia', 'BG': 'Europe', 'BF': 'Africa', 'BI': 'Africa',
    'KH': 'Asia', 'CM': 'Africa', 'CA': 'North America', 'CV': 'Africa', 'CF': 'Africa',
    'TD': 'Africa', 'CL': 'South America', 'CN': 'Asia', 'CO': 'South America', 'KM': 'Africa',
    'CG': 'Africa', 'CD': 'Africa', 'CR': 'North America', 'HR': 'Europe',
    'CU': 'North America', 'CY': 'Asia', 'CZ': 'Europe', 'DK': 'Europe', 'DJ': 'Africa',
    'DM': 'North America', 'DO': 'North America', 'EC': 'South America', 'EG': 'Africa', 'SV': 'North America',
    'GQ': 'Africa', 'ER': 'Africa', 'EE': 'Europe', 'SZ': 'Africa', 'ET': 'Africa',
    'FJ': 'Oceania', 'FI': 'Europe', 'FR': 'Europe', 'GA': 'Africa', 'GM': 'Africa',
    'GE': 'Asia', 'DE': 'Europe', 'GH': 'Africa', 'GR': 'Europe', 'GD': 'North America',
    'GT': 'North America', 'GN': 'Africa', 'GW': 'Africa', 'GY': 'South America', 'HT': 'North America',
    'HN': 'North America', 'HU': 'Europe', 'IS': 'Europe', 'IN': 'Asia', 'ID': 'Asia',
    'IR': 'Asia', 'IQ': 'Asia', 'IE': 'Europe', 'IL': 'Asia', 'IT': 'Europe',
    'JM': 'North America', 'JP': 'Asia', 'JO': 'Asia', 'KZ': 'Asia', 'KE': 'Africa',
    'KI': 'Oceania', 'KP': 'Asia', 'KR': 'Asia', 'KW': 'Asia', 'KG': 'Asia',
    'LA': 'Asia', 'LV': 'Europe', 'LB': 'Asia', 'LS': 'Africa', 'LR': 'Africa',
    'LY': 'Africa', 'LI': 'Europe', 'LT': 'Europe', 'LU': 'Europe', 'MG': 'Africa',
    'MW': 'Africa', 'MY': 'Asia', 'MV': 'Asia', 'ML': 'Africa', 'MT': 'Europe',
    'MH': 'Oceania', 'MQ': 'North America', 'MR': 'Africa', 'MU': 'Africa',
    'MX': 'North America', 'FM': 'Oceania', 'MD': 'Europe', 'MC': 'Europe', 'MN': 'Asia',
    'ME': 'Europe', 'MA': 'Africa', 'MZ': 'Africa', 'MM': 'Asia', 'NA': 'Africa',
    'NR': 'Oceania', 'NP': 'Asia', 'NL': 'Europe', 'NZ': 'Oceania', 'NI': 'North America',
    'NE': 'Africa', 'NG': 'Africa', 'NO': 'Europe', 'OM': 'Asia', 'PK': 'Asia',
    'PW': 'Oceania', 'PA': 'North America', 'PG': 'Oceania', 'PY': 'South America', 'PE': 'South America',
    'PH': 'Asia', 'PL': 'Europe', 'PT': 'Europe', 'QA': 'Asia', 'RO': 'Europe',
    'RU': 'Europe', 'RW': 'Africa', 'WS': 'Oceania', 'SM': 'Europe', 'ST': 'Africa',
    'SA': 'Asia', 'SN': 'Africa', 'RS': 'Europe', 'SC': 'Africa', 'SL': 'Africa',
    'SG': 'Asia', 'SK': 'Europe', 'SI': 'Europe', 'SB': 'Oceania', 'SO': 'Africa',
    'ZA': 'Africa', 'ES': 'Europe', 'LK': 'Asia', 'SD': 'Africa', 'SR': 'South America',
    'SE': 'Europe', 'CH': 'Europe', 'SY': 'Asia', 'TW': 'Asia', 'TJ': 'Asia',
    'TZ': 'Africa', 'TH': 'Asia', 'TL': 'Asia', 'TG': 'Africa', 'TO': 'Oceania',
    'TT': 'North America', 'TN': 'Africa', 'TR': 'Asia', 'TM': 'Asia',
    'TV': 'Oceania', 'UG': 'Africa', 'UA': 'Europe', 'AE': 'Asia',
    'GB': 'Europe', 'US': 'North America', 'UY': 'South America', 'UZ': 'Asia',
    'VU': 'Oceania', 'VE': 'South America', 'VN': 'Asia', 'YE': 'Asia', 'ZM': 'Africa',
    'ZW': 'Africa'
}
country_mapping = {
    'AF': 'Afghanistan', 'AL': 'Albania', 'DZ': 'Algeria', 'AS': 'American Samoa', 'AD': 'Andorra',
    'AO': 'Angola', 'AI': 'Anguilla', 'AQ': 'Antarctica', 'AG': 'Antigua and Barbuda', 'AR': 'Argentina',
    'AM': 'Armenia', 'AW': 'Aruba', 'AU': 'Australia', 'AT': 'Austria', 'AZ': 'Azerbaijan',
    'BS': 'Bahamas', 'BH': 'Bahrain', 'BD': 'Bangladesh', 'BB': 'Barbados', 'BY': 'Belarus',
    'BE': 'Belgium', 'BZ': 'Belize', 'BJ': 'Benin', 'BM': 'Bermuda', 'BT': 'Bhutan',
    'BO': 'Bolivia', 'BA': 'Bosnia and Herzegovina', 'BW': 'Botswana', 'BR': 'Brazil',
    'BN': 'Brunei Darussalam', 'BG': 'Bulgaria', 'BF': 'Burkina Faso', 'BI': 'Burundi',
    'KH': 'Cambodia', 'CM': 'Cameroon', 'CA': 'Canada', 'CV': 'Cape Verde', 'CF': 'Central African Republic',
    'TD': 'Chad', 'CL': 'Chile', 'CN': 'China', 'CO': 'Colombia', 'KM': 'Comoros',
    'CG': 'Congo', 'CD': 'Congo (Democratic Republic)', 'CR': 'Costa Rica', 'HR': 'Croatia',
    'CU': 'Cuba', 'CY': 'Cyprus', 'CZ': 'Czechia', 'DK': 'Denmark', 'DJ': 'Djibouti',
    'DM': 'Dominica', 'DO': 'Dominican Republic', 'EC': 'Ecuador', 'EG': 'Egypt', 'SV': 'El Salvador',
    'GQ': 'Equatorial Guinea', 'ER': 'Eritrea', 'EE': 'Estonia', 'SZ': 'Eswatini', 'ET': 'Ethiopia',
    'FJ': 'Fiji', 'FI': 'Finland', 'FR': 'France', 'GA': 'Gabon', 'GM': 'Gambia',
    'GE': 'Georgia', 'DE': 'Germany', 'GH': 'Ghana', 'GR': 'Greece', 'GD': 'Grenada',
    'GT': 'Guatemala', 'GN': 'Guinea', 'GW': 'Guinea-Bissau', 'GY': 'Guyana', 'HT': 'Haiti',
    'HN': 'Honduras', 'HU': 'Hungary', 'IS': 'Iceland', 'IN': 'India', 'ID': 'Indonesia',
    'IR': 'Iran', 'IQ': 'Iraq', 'IE': 'Ireland', 'IL': 'Israel', 'IT': 'Italy',
    'JM': 'Jamaica', 'JP': 'Japan', 'JO': 'Jordan', 'KZ': 'Kazakhstan', 'KE': 'Kenya',
    'KI': 'Kiribati', 'KP': 'Korea (North)', 'KR': 'Korea (South)', 'KW': 'Kuwait', 'KG': 'Kyrgyzstan',
    'LA': 'Laos', 'LV': 'Latvia', 'LB': 'Lebanon', 'LS': 'Lesotho', 'LR': 'Liberia',
    'LY': 'Libya', 'LI': 'Liechtenstein', 'LT': 'Lithuania', 'LU': 'Luxembourg', 'MG': 'Madagascar',
    'MW': 'Malawi', 'MY': 'Malaysia', 'MV': 'Maldives', 'ML': 'Mali', 'MT': 'Malta',
    'MH': 'Marshall Islands', 'MQ': 'Martinique', 'MR': 'Mauritania', 'MU': 'Mauritius',
    'MX': 'Mexico', 'FM': 'Micronesia', 'MD': 'Moldova', 'MC': 'Monaco', 'MN': 'Mongolia',
    'ME': 'Montenegro', 'MA': 'Morocco', 'MZ': 'Mozambique', 'MM': 'Myanmar', 'NA': 'Namibia',
    'NR': 'Nauru', 'NP': 'Nepal', 'NL': 'Netherlands', 'NZ': 'New Zealand', 'NI': 'Nicaragua',
    'NE': 'Niger', 'NG': 'Nigeria', 'NO': 'Norway', 'OM': 'Oman', 'PK': 'Pakistan',
    'PW': 'Palau', 'PA': 'Panama', 'PG': 'Papua New Guinea', 'PY': 'Paraguay', 'PE': 'Peru',
    'PH': 'Philippines', 'PL': 'Poland', 'PT': 'Portugal', 'QA': 'Qatar', 'RO': 'Romania',
    'RU': 'Russia', 'RW': 'Rwanda', 'WS': 'Samoa', 'SM': 'San Marino', 'ST': 'Sao Tome and Principe',
    'SA': 'Saudi Arabia', 'SN': 'Senegal', 'RS': 'Serbia', 'SC': 'Seychelles', 'SL': 'Sierra Leone',
    'SG': 'Singapore', 'SK': 'Slovakia', 'SI': 'Slovenia', 'SB': 'Solomon Islands', 'SO': 'Somalia',
    'ZA': 'South Africa', 'ES': 'Spain', 'LK': 'Sri Lanka', 'SD': 'Sudan', 'SR': 'Suriname',
    'SE': 'Sweden', 'CH': 'Switzerland', 'SY': 'Syria', 'TW': 'Taiwan', 'TJ': 'Tajikistan',
    'TZ': 'Tanzania', 'TH': 'Thailand', 'TL': 'Timor-Leste', 'TG': 'Togo', 'TO': 'Tonga',
    'TT': 'Trinidad and Tobago', 'TN': 'Tunisia', 'TR': 'Turkey', 'TM': 'Turkmenistan',
    'TV': 'Tuvalu', 'UG': 'Uganda', 'UA': 'Ukraine', 'AE': 'United Arab Emirates',
    'GB': 'United Kingdom', 'US': 'United States', 'UY': 'Uruguay', 'UZ': 'Uzbekistan',
    'VU': 'Vanuatu', 'VE': 'Venezuela', 'VN': 'Vietnam', 'YE': 'Yemen', 'ZM': 'Zambia',
    'ZW': 'Zimbabwe'
}

db_path = 'app.db'

conn = sqlite3.connect(db_path)
cursor = conn.cursor()

insert_destination_stmt = """
    INSERT INTO destination (name, country, continent, population)
    VALUES (?, ?, ?, ?)
"""

data_file = 'cities15000.txt'


with open(data_file, 'r', encoding='utf-8') as file:
    reader = csv.reader(file, delimiter='\t')
    batch_size = 1000
    batch = []

    for row in reader:
        if len(row) >= 15:
            city_name = row[1]
            country_code = row[8]
            population_str = row[14]

            try:
                population = int(population_str)
            except ValueError:
                population = None

            # Map country code to country name and continent
            country_name = country_mapping.get(country_code)
            continent_name = continent_mapping.get(country_code)

            if country_name and continent_name:
                batch.append((city_name, country_name, continent_name, population))

            # Insert in batches to optimize performance
            if len(batch) == batch_size:
                cursor.executemany(insert_destination_stmt, batch)
                conn.commit()
                print(f"Inserted batch of {batch_size} records.")
                batch = []

    # Insert any remaining records
    if batch:
        cursor.executemany(insert_destination_stmt, batch)
        conn.commit()
        print(f"Inserted final batch of {len(batch)} records.")

# Close the connection
cursor.close()
conn.close()

print("Data import completed successfully.")